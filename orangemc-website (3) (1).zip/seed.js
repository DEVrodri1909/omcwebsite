// Run `npm start` once first (creates tables), stop it, then `npm run seed`. Safe to re-run.
// Ranks are delivered to RANK_SERVER (default lobby). Use RANK_SERVER=all if LuckPerms is NOT shared between servers.
require('dotenv').config();
const db=require('better-sqlite3')(process.env.DB_PATH||'store.db'),SV=process.env.RANK_SERVER||'lobby';
const cat=(n,s,o)=>{db.prepare('INSERT OR IGNORE INTO categories(name,slug,sort) VALUES(?,?,?)').run(n,s,o);return db.prepare('SELECT id FROM categories WHERE slug=?').get(s).id};
const m=cat('Monthly Ranks','monthly',1),l=cat('Lifetime Ranks','lifetime',2);
for(const[n,g,mo,li]of[['Lemon','lemon',100,500],['Lemon+','lemonplus',200,1000],['Orange','orange',400,1500],['Orange+','orangeplus',500,2000]])
 for(const[c,name,p,cmd,d]of[[m,n+' (Monthly)',mo,`lp user %player% parent addtemp ${g} 30d accumulate`,'30 days'],[l,n+' (Lifetime)',li,`lp user %player% parent add ${g}`,'permanent']])
  if(!db.prepare('SELECT 1 FROM products WHERE name=?').get(name))db.prepare('INSERT INTO products(category_id,name,description,price_cents,commands,server) VALUES(?,?,?,?,?,?)').run(c,name,`${n} rank – ${d}`,p,JSON.stringify([cmd]),SV);
console.log('Seeded ranks for server',SV);
