# OrangeMC Website + Store (Node.js 18+)
1. `cp .env.example .env` and fill it in (PayPal Client ID/Secret/Webhook ID, ADMIN_TOKEN, SITE_URL, SERVER_KEYS).
   Payments go to PAYPAL_PAYEE_EMAIL (rodricbcinco16@gmail.com) – the PayPal REST app must belong to that PayPal account.
2. `npm install && npm start` (creates `store.db`). Optional: stop it, `npm run seed`, start again to create the 8 ranks.
3. Put it behind HTTPS. Pages: `/` home, `/store.html` store, `/admin.html` admin (login with ADMIN_TOKEN).
4. PayPal webhook -> `https://YOUR-DOMAIN/api/paypal/webhook` (events PAYMENT.CAPTURE.COMPLETED/PENDING/DENIED/DECLINED/REFUNDED/REVERSED).

## Servers
`SERVER_KEYS=seasons:KEY1,practice:KEY2,lobby:KEY3,economy:KEY4` – every Minecraft server has its own key (use long random strings).
Each product has a `server` field (`seasons`, `practice`, `lobby`, `economy` or `all`): its commands only run on that server.
