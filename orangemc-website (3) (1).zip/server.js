require('dotenv').config();
const express=require('express'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),Database=require('better-sqlite3'),crypto=require('crypto');
const E=process.env,PP=E.PAYPAL_ENV==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com',CUR=E.CURRENCY||'USD';
for(const k of ['PAYPAL_CLIENT_ID','PAYPAL_CLIENT_SECRET','PAYPAL_WEBHOOK_ID','PAYPAL_PAYEE_EMAIL','ADMIN_TOKEN','SERVER_KEYS','SITE_URL'])if(!E[k]){console.error('Missing env '+k);process.exit(1)}
const db=new Database(E.DB_PATH||'store.db');db.pragma('journal_mode=WAL');db.pragma('foreign_keys=ON');
db.exec(`
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY,name TEXT NOT NULL,slug TEXT UNIQUE NOT NULL,sort INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,category_id INTEGER REFERENCES categories(id),name TEXT NOT NULL,description TEXT DEFAULT '',price_cents INTEGER NOT NULL CHECK(price_cents>0),image TEXT DEFAULT '',commands TEXT DEFAULT '[]',server TEXT DEFAULT 'all',active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS discount_codes(id INTEGER PRIMARY KEY,code TEXT UNIQUE NOT NULL,percent INTEGER,fixed_cents INTEGER,max_uses INTEGER,uses INTEGER DEFAULT 0,active INTEGER DEFAULT 1,expires_at INTEGER);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,username TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'created',total_cents INTEGER NOT NULL,currency TEXT NOT NULL,discount_code TEXT,paypal_order_id TEXT,created_at INTEGER NOT NULL,paid_at INTEGER);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),product_id INTEGER,name TEXT,price_cents INTEGER,quantity INTEGER,commands TEXT,server TEXT);
CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY,order_id TEXT NOT NULL,capture_id TEXT UNIQUE NOT NULL,amount_cents INTEGER,currency TEXT,status TEXT,created_at INTEGER);
CREATE TABLE IF NOT EXISTS webhook_events(id TEXT PRIMARY KEY,type TEXT,created_at INTEGER);
CREATE TABLE IF NOT EXISTS deliveries(id INTEGER PRIMARY KEY,order_id TEXT NOT NULL,order_item_id INTEGER NOT NULL,server TEXT NOT NULL,username TEXT NOT NULL,commands TEXT NOT NULL,quantity INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',claimed_at INTEGER,delivered_at INTEGER,UNIQUE(order_item_id,server));
CREATE INDEX IF NOT EXISTS i_user ON orders(username);CREATE INDEX IF NOT EXISTS i_del ON deliveries(status);`);
const now=()=>Math.floor(Date.now()/1000),app=express();
app.set('trust proxy',1);app.use(helmet({contentSecurityPolicy:false}));app.use(express.json({limit:'100kb'}));
app.use('/api',rateLimit({windowMs:60000,limit:120,standardHeaders:true,legacyHeaders:false}));
const eq=(a,b)=>{a=Buffer.from(String(a));b=Buffer.from(String(b));return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const bearer=(tok)=>(q,s,n)=>eq((q.headers.authorization||'').replace(/^Bearer /,''),tok)?n():s.status(401).json({error:'unauthorized'});
const admin=bearer(E.ADMIN_TOKEN);
// SERVER_KEYS=seasons:key1,practice:key2,lobby:key3,economy:key4 -> each Minecraft server has its own key
const SERVERS=Object.fromEntries(E.SERVER_KEYS.split(',').map(x=>x.trim().split(':')).filter(a=>a.length===2&&a[0]&&a[1]));
const plugin=(q,s,n)=>{const k=(q.headers.authorization||'').replace(/^Bearer /,'');for(const[id,key]of Object.entries(SERVERS))if(eq(k,key)){q.server=id;return n()}s.status(401).json({error:'unauthorized'})};
const wrap=f=>(q,s)=>Promise.resolve(f(q,s)).catch(e=>{console.error(e);s.status(500).json({error:'server error'})});
// ---- PayPal
let tok={v:null,exp:0};
async function pp(path,method='GET',body){
  if(Date.now()>tok.exp){const r=await fetch(PP+'/v1/oauth2/token',{method:'POST',headers:{Authorization:'Basic '+Buffer.from(E.PAYPAL_CLIENT_ID+':'+E.PAYPAL_CLIENT_SECRET).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});const j=await r.json();if(!r.ok)throw new Error('PayPal auth failed');tok={v:j.access_token,exp:Date.now()+(j.expires_in-60)*1000}}
  const r=await fetch(PP+path,{method,headers:{Authorization:'Bearer '+tok.v,'Content-Type':'application/json'},body:body&&JSON.stringify(body)});
  const j=await r.json().catch(()=>({}));return{ok:r.ok,status:r.status,data:j}}
const money=c=>(c/100).toFixed(2);
// ---- Public API
app.get('/api/categories',(q,s)=>s.json(db.prepare('SELECT * FROM categories ORDER BY sort,name').all()));
app.get('/api/products',(q,s)=>{const w=q.query.category?' AND c.slug=?':'';const a=q.query.category?[q.query.category]:[];
  s.json(db.prepare(`SELECT p.id,p.name,p.description,p.price_cents,p.image,c.slug category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1${w}`).all(...a))});
app.get('/api/products/:id',(q,s)=>{const p=db.prepare('SELECT id,name,description,price_cents,image,category_id FROM products WHERE id=? AND active=1').get(q.params.id);p?s.json(p):s.status(404).json({error:'not found'})});
function discountFor(code,sub){if(!code)return{cents:0};const d=db.prepare('SELECT * FROM discount_codes WHERE code=? COLLATE NOCASE AND active=1').get(code);
  if(!d||(d.expires_at&&d.expires_at<now())||(d.max_uses!=null&&d.uses>=d.max_uses))return{error:'Invalid or expired code'};
  const c=d.percent?Math.floor(sub*d.percent/100):Math.min(d.fixed_cents||0,sub);return{cents:c,code:d.code}}
function price(items,code){if(!Array.isArray(items)||!items.length||items.length>30)return{error:'Cart is empty'};let sub=0;const rows=[];
  for(const it of items){const qty=Number(it.quantity||1),p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(Number(it.productId));
    if(!p||!Number.isInteger(qty)||qty<1||qty>20)return{error:'Invalid item'};sub+=p.price_cents*qty;rows.push({p,qty})}
  const d=discountFor(code,sub);if(d.error)return d;const total=Math.max(sub-d.cents,0);if(total<1)return{error:'Total too low'};return{rows,sub,total,code:d.code||null,discount:d.cents}}
app.post('/api/discounts/validate',wrap((q,s)=>{const r=price(q.body.items,q.body.code);r.error?s.status(400).json({error:r.error}):s.json({subtotal_cents:r.sub,discount_cents:r.discount,total_cents:r.total})}));
const USER=/^[A-Za-z0-9_]{3,16}$/;
app.post('/api/orders',rateLimit({windowMs:60000,limit:15}),wrap(async(q,s)=>{
  const u=String(q.body.username||'').trim();if(!USER.test(u))return s.status(400).json({error:'Enter a valid Minecraft username (3-16 letters, numbers, underscore)'});
  const r=price(q.body.items,q.body.code);if(r.error)return s.status(400).json({error:r.error});
  const id=crypto.randomUUID();
  const res=await pp('/v2/checkout/orders','POST',{intent:'CAPTURE',purchase_units:[{reference_id:id,custom_id:id,description:'OrangeMC store order for '+u,
    amount:{currency_code:CUR,value:money(r.total)},payee:{email_address:E.PAYPAL_PAYEE_EMAIL}}],
    application_context:{brand_name:'OrangeMC',user_action:'PAY_NOW',return_url:`${E.SITE_URL}/success.html?order=${id}`,cancel_url:`${E.SITE_URL}/cancelled.html?order=${id}`}});
  if(!res.ok){console.error(JSON.stringify(res.data));return s.status(502).json({error:'Payment provider error'})}
  db.transaction(()=>{db.prepare('INSERT INTO orders(id,username,total_cents,currency,discount_code,paypal_order_id,created_at) VALUES(?,?,?,?,?,?,?)').run(id,u,r.total,CUR,r.code,res.data.id,now());
    for(const{p,qty}of r.rows)db.prepare('INSERT INTO order_items(order_id,product_id,name,price_cents,quantity,commands,server) VALUES(?,?,?,?,?,?,?)').run(id,p.id,p.name,p.price_cents,qty,p.commands,p.server)})();
  const link=(res.data.links.find(l=>l.rel==='approve')||res.data.links.find(l=>l.rel==='payer-action')||{}).href;
  s.json({orderId:id,approveUrl:link})}));
// Marks an order paid exactly once (idempotent; amount verified server-side)
function markPaid(orderId,cap){return db.transaction(()=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(orderId);if(!o)return'unknown';
  if(db.prepare('SELECT 1 FROM transactions WHERE capture_id=?').get(cap.id))return'duplicate';
  const cents=Math.round(parseFloat(cap.amount.value)*100);
  if(cents!==o.total_cents||cap.amount.currency_code!==o.currency){db.prepare("UPDATE orders SET status='review' WHERE id=?").run(orderId);return'mismatch'}
  db.prepare('INSERT INTO transactions(order_id,capture_id,amount_cents,currency,status,created_at) VALUES(?,?,?,?,?,?)').run(orderId,cap.id,cents,cap.amount.currency_code,cap.status,now());
  db.prepare("UPDATE orders SET status='paid',paid_at=? WHERE id=? AND status!='paid'").run(now(),orderId);
  if(o.discount_code)db.prepare('UPDATE discount_codes SET uses=uses+1 WHERE code=? COLLATE NOCASE').run(o.discount_code);
  for(const it of db.prepare('SELECT * FROM order_items WHERE order_id=?').all(orderId))
    for(const sv of(!it.server||it.server==='all')?Object.keys(SERVERS):[it.server])
      db.prepare('INSERT OR IGNORE INTO deliveries(order_id,order_item_id,server,username,commands,quantity) VALUES(?,?,?,?,?,?)').run(orderId,it.id,sv,o.username,it.commands,it.quantity);
  return'paid'})()}
// Called by success page after PayPal redirect: server captures and verifies (never trusts the client)
app.post('/api/orders/:id/capture',wrap(async(q,s)=>{const o=db.prepare('SELECT * FROM orders WHERE id=?').get(q.params.id);if(!o)return s.status(404).json({error:'not found'});
  if(o.status==='paid')return s.json({status:'paid'});
  const r=await pp(`/v2/checkout/orders/${o.paypal_order_id}/capture`,'POST');
  const cap=r.data?.purchase_units?.[0]?.payments?.captures?.[0];
  if(!r.ok||!cap){const g=await pp(`/v2/checkout/orders/${o.paypal_order_id}`);const c2=g.data?.purchase_units?.[0]?.payments?.captures?.[0];if(!c2)return s.status(400).json({error:'Payment not completed',status:o.status});return finish(c2)}
  return finish(cap);
  function finish(c){if(c.status==='COMPLETED'){const x=markPaid(o.id,c);return s.json({status:x==='mismatch'?'review':'paid'})}
    if(c.status==='PENDING'){db.prepare("UPDATE orders SET status='pending' WHERE id=? AND status!='paid'").run(o.id);return s.json({status:'pending'})}
    db.prepare("UPDATE orders SET status='failed' WHERE id=? AND status!='paid'").run(o.id);s.json({status:'failed'})}}));
app.get('/api/orders/:id',(q,s)=>{const o=db.prepare('SELECT id,username,status,total_cents,currency,created_at FROM orders WHERE id=?').get(q.params.id);
  o?s.json({...o,items:db.prepare('SELECT name,quantity,price_cents FROM order_items WHERE order_id=?').all(o.id)}):s.status(404).json({error:'not found'})});
app.get('/api/servers',(q,s)=>s.json(Object.keys(SERVERS)));
app.get('/api/history',rateLimit({windowMs:60000,limit:20}),(q,s)=>{const u=String(q.query.username||'');if(!USER.test(u))return s.status(400).json({error:'Invalid username'});
  s.json(db.prepare('SELECT id,status,total_cents,currency,created_at FROM orders WHERE lower(username)=lower(?) ORDER BY created_at DESC LIMIT 20').all(u))});
// ---- PayPal webhook (signature verified with PayPal)
app.post('/api/paypal/webhook',wrap(async(q,s)=>{const h=q.headers,ev=q.body;
  const v=await pp('/v1/notifications/verify-webhook-signature','POST',{auth_algo:h['paypal-auth-algo'],cert_url:h['paypal-cert-url'],transmission_id:h['paypal-transmission-id'],transmission_sig:h['paypal-transmission-sig'],transmission_time:h['paypal-transmission-time'],webhook_id:E.PAYPAL_WEBHOOK_ID,webhook_event:ev});
  if(!v.ok||v.data.verification_status!=='SUCCESS')return s.status(400).json({error:'bad signature'});
  if(db.prepare('SELECT 1 FROM webhook_events WHERE id=?').get(ev.id))return s.json({ok:true,duplicate:true});
  db.prepare('INSERT INTO webhook_events VALUES(?,?,?)').run(ev.id,ev.event_type,now());
  const r=ev.resource||{},oid=r.custom_id;
  if(oid){switch(ev.event_type){
    case'PAYMENT.CAPTURE.COMPLETED':markPaid(oid,r);break;
    case'PAYMENT.CAPTURE.PENDING':db.prepare("UPDATE orders SET status='pending' WHERE id=? AND status!='paid'").run(oid);break;
    case'PAYMENT.CAPTURE.DENIED':case'PAYMENT.CAPTURE.DECLINED':db.prepare("UPDATE orders SET status='failed' WHERE id=? AND status!='paid'").run(oid);break;
    case'PAYMENT.CAPTURE.REFUNDED':case'PAYMENT.CAPTURE.REVERSED':db.prepare("UPDATE orders SET status='refunded' WHERE id=?").run(oid);db.prepare("UPDATE deliveries SET status='cancelled' WHERE order_id=? AND status IN('pending','claimed')").run(oid);break}}
  s.json({ok:true})}));
// ---- Minecraft plugin API
app.get('/api/plugin/pending',plugin,(q,s)=>{const names=String(q.query.online||'').toLowerCase().split(',').filter(n=>USER.test(n)).slice(0,200);if(!names.length)return s.json([]);
  const rows=db.transaction(()=>{const rs=db.prepare(`SELECT id,username,commands,quantity FROM deliveries WHERE server=? AND (status='pending' OR (status='claimed' AND claimed_at<?)) AND lower(username) IN (${names.map(()=>'?').join(',')}) LIMIT 50`).all(q.server,now()-120,...names);
    for(const r of rs)db.prepare("UPDATE deliveries SET status='claimed',claimed_at=? WHERE id=?").run(now(),r.id);return rs})();
  s.json(rows.map(r=>({...r,commands:JSON.parse(r.commands||'[]')})))});
app.post('/api/plugin/ack',plugin,(q,s)=>{const{id,success}=q.body;
  const r=db.prepare("UPDATE deliveries SET status=?,delivered_at=? WHERE id=? AND status='claimed'").run(success?'delivered':'pending',success?now():null,Number(id));s.json({updated:r.changes})});
// ---- Admin API
const J=v=>Array.isArray(v)?JSON.stringify(v):v;
function crud(name,table,cols){const p=`/api/admin/${name}`;
  app.get(p,admin,(q,s)=>s.json(db.prepare(`SELECT * FROM ${table}`).all()));
  app.post(p,admin,(q,s)=>{try{const k=cols.filter(c=>q.body[c]!==undefined);const r=db.prepare(`INSERT INTO ${table}(${k.join(',')}) VALUES(${k.map(()=>'?').join(',')})`).run(...k.map(c=>J(q.body[c])));s.json({id:r.lastInsertRowid})}catch(e){s.status(400).json({error:e.message})}});
  app.put(p+'/:id',admin,(q,s)=>{try{const k=cols.filter(c=>q.body[c]!==undefined);if(!k.length)return s.status(400).json({error:'nothing to update'});db.prepare(`UPDATE ${table} SET ${k.map(c=>c+'=?').join(',')} WHERE id=?`).run(...k.map(c=>J(q.body[c])),q.params.id);s.json({ok:true})}catch(e){s.status(400).json({error:e.message})}});
  app.delete(p+'/:id',admin,(q,s)=>{try{db.prepare(`DELETE FROM ${table} WHERE id=?`).run(q.params.id);s.json({ok:true})}catch(e){s.status(400).json({error:e.message})}})}
crud('categories','categories',['name','slug','sort']);
crud('products','products',['category_id','name','description','price_cents','image','commands','server','active']);
crud('discounts','discount_codes',['code','percent','fixed_cents','max_uses','active','expires_at']);
app.get('/api/admin/orders',admin,(q,s)=>{const u=q.query.username;const rows=db.prepare(`SELECT o.*,(SELECT group_concat(status) FROM deliveries d WHERE d.order_id=o.id) delivery FROM orders o ${u?"WHERE lower(username) LIKE ?":''} ORDER BY created_at DESC LIMIT 200`).all(...(u?['%'+String(u).toLowerCase()+'%']:[]));s.json(rows)});
app.post('/api/admin/orders/:id/redeliver',admin,(q,s)=>{const r=db.prepare("UPDATE deliveries SET status='pending' WHERE order_id=? AND status!='cancelled'").run(q.params.id);s.json({requeued:r.changes})});
app.get('/api/admin/stats',admin,(q,s)=>s.json(db.prepare("SELECT count(*) paid_orders,coalesce(sum(total_cents),0) revenue_cents FROM orders WHERE status='paid'").get()));
app.use(express.static(__dirname+'/public'));
app.listen(E.PORT||3000,()=>console.log('OrangeMC store on :'+(E.PORT||3000)));
